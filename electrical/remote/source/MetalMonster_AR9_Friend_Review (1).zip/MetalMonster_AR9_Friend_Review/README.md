# Metal Monster AR-9 — friend review (KiCad 9)

Extract the entire ZIP first, keeping the folder structure. In KiCad 9 open remote.kicad_pro, then open remote.kicad_sch or remote.kicad_pcb. For 3D preview use PCB Editor > View > 3D Viewer (Alt+3).

The project contains the schematic, board, custom rules, project-local symbol/footprint libraries and tables, required available models including COM-09032.step. The Griffin artwork has been removed from this PCB. Library paths use ${KIPRJMOD}; all available stock models are bundled under models/stock. Selected standard symbol definitions retain their original KiCad names; their source is the installed KiCad 9 library.

## ML1 and ML2 — both mandatory

Both are short solid-wire connections for GPIO35 / joystick X. ML1 is at KiCad X=52,Y=88 mm; ML2 at X=94,Y=83.4 mm (component-side coordinates). Each uses an UNPLATED 0.8 mm hole and a 2 mm exposed copper pad on BOTH faces (0.6 mm radial annulus). Insert 0.4–0.5 mm solid tinned wire; solder independently to top AND bottom before mounting components; trim to <=0.5 mm protrusion per face. Two wires/four solder joints. Do not assume a plated barrel or solder wicking. Omitting either wire breaks joystick X. All load ground is connected on B.Cu without either wire. All 72 holes are intended UNPLATED, although native net-bearing THT objects can look plated.

## Existing model and physical limits

The original project references a JST XA plastic-body STEP file absent from this KiCad installation. That optional standard-variable reference is retained unchanged; J3/J4/J5/J6 footprints resolve, but their plastic bodies may be absent in 3D. No replacement model was invented. C1 and the full ESP32 body also have no model in the source. The joystick STEP is included. The blue XL4015 solid is only the existing estimated body envelope, not a measured module.

This is a REVIEW DRAFT, NO-GO for fabrication: converter mounting/terminal/underside geometry, actual joystick/ESP32/USB/antenna/enclosure fit, power-system operation and factory all-NPTH handling remain unverified. XL4015's specified 8 V minimum input does not cover nominal 7.4 V 2S operation. No manufacturing data or fabrication approval is included.

Source design was not modified. In this review copy only library tables and available model path strings were made portable; board geometry, routing, component placement and the entire schematic are preserved.
